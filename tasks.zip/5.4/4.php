<?
    error_reporting(-1);
    $id = $_GET['id'];
    $mysqli = new mysqli("localhost", "qwerty1", "123321", "qwerty1");
    

    if ($mysqli->connect_errno) {
        printf("Не удалось подключиться: %s\n", $mysqli->connect_error);
        exit();
    }

    $mysqli->query("SET NAMES UTF8");
    if ($result = $mysqli->query("SELECT * from pages WHERE id=$id")) {
        $obj = $result->fetch_array();
        $result->close();
    }

    $mysqli->close();
?>
<html>
<head>
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
	<title><?echo($obj[1]);?></title>
</head>
<body>  
  <div id="center">
		<?echo($obj[2]);?>
  </div>
  </body>
</html>
