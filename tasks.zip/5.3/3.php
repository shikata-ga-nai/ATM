<?
    error_reporting(-1);
    $id = $_POST['input'];

    $mysqli = new mysqli("localhost", "tqqqq", "123321123321", "qrvet");
    

    if ($mysqli->connect_errno) {
        printf("Не удалось подключиться: %s\n", $mysqli->connect_error);
        exit();
    }

    $mysqli->query("SET NAMES UTF8");
    if ($result = $mysqli->query("SELECT $id")) {
        $obj = $result->fetch_array();
        $result->close();
    }

    $mysqli->close();
?>
<html>
<head>
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
	<title>Користувач</title>
</head>
<body>  
  <div id="center">
            <form method="POST" action="3.php">
                Input: <input type="text" name='input' id="input">&nbsp;<input type="submit" value="Запит">
            </form><br/>
	    	Запит виду: "SELECT $input"
            Який же пароль у користувача?
  </div>
  </body>
</html>
