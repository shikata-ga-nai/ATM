<?
	error_reporting(E_ALL);
	ini_set('display_errors', 'on');
	$system = "Перша сторінка тощо";
	if (!empty($_GET)) {
		if ($_GET['mode']=='vlt') {
			eval($_GET['function']."(".$_GET['variable'].");");
		}

		if ($_GET['mode']=='imprt') {
			include($_GET['os'].".php");
		}

	}
	if (empty($_GET)):
?>
<ul>
	<li> - <a href="?function=echo&mode=vlt&os=linux&exec=true&status=true&variable=$system&command=show">Перша сторінка</a>!</li>
	<li> - <a href="?function=echo&mode=imprt&os=windows&command=show&exec=false&status=true&variable=$users">Друга сторінка</a>!</li>

</ul>
<?endif;?>