<?
    error_reporting(-1);
    $id = $_GET['id'];
    $id = str_replace("'","",$id);
    $id = str_replace("\"","",$id);
    $id = str_replace(",","",$id);
    $id = str_replace(" ","",$id);
    $id = str_replace(")","",$id);
    $id = str_replace("(","",$id);
        
        //',",+,=,запятая,пробел,скобки
    $mysqli = new mysqli("localhost", "ytrewq2", "123321", "ytrewq22");
    

    if ($mysqli->connect_errno) {
        printf("Не удалось подключиться: %s\n", $mysqli->connect_error);
        exit();
    }

    $mysqli->query("SET NAMES UTF8");
    if ($result = $mysqli->query("SELECT * from users WHERE id=$id limit 1")) {
        $obj = $result->fetch_array();
        $result->close();
    }

    $mysqli->close();
?>
<html>
<head>
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
	<title>Користувач</title>
</head>
<body>  
  <div id="center">
		А ось і користувач з логіном "<?echo($obj[1]);?>" та паролем "<?echo($obj[2]);?>", а є у нас користувач, в логіні якого є "login". Який же пароль у нього?
  </div>
  </body>
</html>
