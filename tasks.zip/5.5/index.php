<?
  if ($_GET['logout']) {
        setcookie( 'login' , '' , time()-3600); 
        unset($_COOKIE['login']);

        setcookie( 'password' , '' , time()-3600); 
        unset($_COOKIE['password']);

        setcookie( 'name' , '' , time()-3600); 
        unset($_COOKIE['name']);

        setcookie( 'status' , '' , time()-3600); 
        unset($_COOKIE['status']);

        setcookie( 'flag' , '' , time()-3600); 
        unset($_COOKIE['flag']);

        setcookie( 'ip' , '' , time()-3600); 
        unset($_COOKIE['ip']);
 
  }?><html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>Знайти флаг</title>
  </head>
  <body>
  	<?
      if (!isset($_COOKIE['flag'])) {
		    setcookie("ip", $_SERVER['REMOTE_ADDR']);
        if (!empty($_SERVER["HTTP_CLIENT_IP"]))
        {
         $ip = $_SERVER["HTTP_CLIENT_IP"];
        }
        elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"]))
        {
         $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
        }
        else
        {
         $ip = $_SERVER["REMOTE_ADDR"];
        }

		    setcookie("flag", "1tW@SZ03Asy");
		  }
      
  		if (empty($_POST['name'])):
  			echo "<i>Ви зайшли в темний ліс та зустріли чаклуна.<br/> Він:</i><br/>";
        if (empty($_COOKIE['login'])){
          echo "- Вітаю, <b>незнайомець</b>!<br/>Представся та продовжи свій шлях!<br/><img src='1.jpg' width='400' align='right'>";
        }
        else {
          echo "- Вітаю, <b>".$_COOKIE['status']." ".$_COOKIE['login']."</b>!<br/>Мені здається, ти вже тут був! <a href='?logout=true'>Ні</a>?<br/><img src='1.jpg' width='400' align='right'>";
        }
  			
  	?>
  		<i>Ви:</i> <br/><form action="" method="POST"> 
        Звання: <input type="text" name="status" value=""/> 
  			Ім'я: <input type="text" name="name" value=""/> 
  			Чарівний ключ: <input type="password" name="password" value=""/> 
  			<input type="submit" value="Це я!"/> 
  		</form>
  	<?
  		else:
        setcookie("login", $_POST['name']);
        setcookie("password", $_POST['password']);
        setcookie("status", $_POST['status']);
        
        echo "<i>Чаклун</i>:<br/> Да хай тобі добре буде, <b>".$status." ".$name."</b>!<br/>Йди своєю дорогою, проте знай, що я запам'ятав тебе! Або може ти хочеш <a href='./'>повернутись?</a><img src='1.jpg' width='400' align='right'><br/><br/><br/><br/><br/>";
  		endif;
	?>
 </body>
</html>

